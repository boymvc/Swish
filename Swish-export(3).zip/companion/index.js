import { settingsStorage } from "settings";
import * as messaging from "messaging";

settingsStorage.onchange = function(evt) {
  if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
    if (evt.key === "theme") {
      let data = JSON.parse(evt.newValue);
      console.log("Settings data is: ");
      console.log(data);
      console.log(data["values"][0].value);
      messaging.peerSocket.send(data["values"][0].value);
    }
  }
}